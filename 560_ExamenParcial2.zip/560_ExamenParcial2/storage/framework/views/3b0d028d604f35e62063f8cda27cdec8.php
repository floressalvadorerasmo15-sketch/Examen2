

<?php $__env->startSection('title', 'Detalle del Producto'); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-md-8">

        <div class="card shadow-sm">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">🔍 Detalle del Producto</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th width="30%">ID</th>
                        <td><?php echo e($producto->id); ?></td>
                    </tr>
                    <tr>
                        <th>Nombre</th>
                        <td><?php echo e($producto->nombre); ?></td>
                    </tr>
                    <tr>
                        <th>SKU</th>
                        <td><code><?php echo e($producto->sku); ?></code></td>
                    </tr>
                    <tr>
                        <th>Categoría</th>
                        <td><?php echo e($producto->categoria->nombre ?? '—'); ?></td>
                    </tr>
                    <tr>
                        <th>Precio</th>
                        <td>Bs. <?php echo e(number_format($producto->precio, 2)); ?></td>
                    </tr>
                    <tr>
                        <th>Stock</th>
                        <td><?php echo e($producto->stock); ?></td>
                    </tr>
                    <tr>
                        <th>Disponible</th>
                        <td>
                            <?php if($producto->disponible): ?>
                                <span class="badge bg-success">Sí</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">No</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Creado</th>
                        <td><?php echo e($producto->created_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                    <tr>
                        <th>Actualizado</th>
                        <td><?php echo e($producto->updated_at->format('d/m/Y H:i')); ?></td>
                    </tr>
                </table>

                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('productos.edit', $producto)); ?>"
                       class="btn btn-warning">✏️ Editar</a>
                    <a href="<?php echo e(route('productos.index')); ?>"
                       class="btn btn-secondary">← Volver</a>
                </div>

            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\backend_560\560_ExamenParcial2\resources\views/productos/show.blade.php ENDPATH**/ ?>