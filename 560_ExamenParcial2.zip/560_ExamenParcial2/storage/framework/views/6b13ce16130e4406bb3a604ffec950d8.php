<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Gestión de Productos'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

    
    <nav class="bg-gray-900 text-white px-6 py-4 shadow mb-8">
        <div class="max-w-6xl mx-auto flex items-center justify-between">
            <a href="<?php echo e(route('productos.index')); ?>"
               class="text-xl font-bold tracking-wide hover:text-yellow-400 transition">
                🛒 Catálogo de Productos
            </a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-4">

        
        <?php if(session('success')): ?>
            <div class="mb-6 flex items-center justify-between bg-green-100 border border-green-400 text-green-800 px-4 py-3 rounded">
                <span><?php echo e(session('success')); ?></span>
                <button onclick="this.parentElement.remove()" class="text-green-800 font-bold ml-4">✕</button>
            </div>
        <?php endif; ?>

        
        <?php if(session('error')): ?>
            <div class="mb-6 flex items-center justify-between bg-red-100 border border-red-400 text-red-800 px-4 py-3 rounded">
                <span><?php echo e(session('error')); ?></span>
                <button onclick="this.parentElement.remove()" class="text-red-800 font-bold ml-4">✕</button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\backend_560\560_ExamenParcial2\resources\views/layouts/app.blade.php ENDPATH**/ ?>