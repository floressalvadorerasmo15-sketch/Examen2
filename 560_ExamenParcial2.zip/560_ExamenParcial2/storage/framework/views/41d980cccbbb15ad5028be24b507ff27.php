

<?php $__env->startSection('title', 'Lista de Productos'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex items-center justify-between mb-6">
    <h2 class="text-2xl font-bold text-gray-800">📦 Productos</h2>
    <a href="<?php echo e(route('productos.create')); ?>"
       class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow transition">
        + Nuevo Producto
    </a>
</div>

<div class="bg-white rounded-xl shadow overflow-hidden">
    <table class="min-w-full text-sm text-left">
        <thead class="bg-gray-900 text-white">
            <tr>
                <th class="px-4 py-3">#</th>
                <th class="px-4 py-3">Nombre</th>
                <th class="px-4 py-3">Codigo</th>
                <th class="px-4 py-3">Categoría</th>
                <th class="px-4 py-3">Precio</th>
                <th class="px-4 py-3">Stock</th>
                <th class="px-4 py-3">Disponible</th>
                <th class="px-4 py-3 text-center">Acciones</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50 transition">
                <td class="px-4 py-3 text-gray-500"><?php echo e($producto->id); ?></td>
                <td class="px-4 py-3 font-medium text-gray-800"><?php echo e($producto->nombre); ?></td>
                <td class="px-4 py-3">
                    <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded font-mono text-xs">
                        <?php echo e($producto->codigo); ?>

                    </span>
                </td>
                <td class="px-4 py-3 text-gray-600"><?php echo e($producto->categoria->nombre ?? '—'); ?></td>
                <td class="px-4 py-3 text-gray-800 font-semibold">
                    Bs. <?php echo e(number_format($producto->precio, 2)); ?>

                </td>
                <td class="px-4 py-3 text-gray-700"><?php echo e($producto->stock); ?></td>
                <td class="px-4 py-3">
                    <?php if($producto->disponible): ?>
                        <span class="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-full">Sí</span>
                    <?php else: ?>
                        <span class="bg-gray-200 text-gray-600 text-xs font-semibold px-2 py-1 rounded-full">No</span>
                    <?php endif; ?>
                </td>
                <td class="px-4 py-3 text-center space-x-1">
                    
                    <a href="<?php echo e(route('productos.show', $producto)); ?>"
                       class="inline-block bg-cyan-500 hover:bg-cyan-600 text-white text-xs font-semibold px-3 py-1 rounded transition">
                        Ver
                    </a>

                    
                    <a href="<?php echo e(route('productos.edit', $producto)); ?>"
                       class="inline-block bg-yellow-400 hover:bg-yellow-500 text-white text-xs font-semibold px-3 py-1 rounded transition">
                        Editar
                    </a>

                    
                    <form action="<?php echo e(route('productos.destroy', $producto)); ?>"
                          method="POST"
                          class="inline-block"
                          onsubmit="return confirm('¿Estás seguro de eliminar: <?php echo e($producto->nombre); ?>?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit"
                                class="bg-red-500 hover:bg-red-600 text-white text-xs font-semibold px-3 py-1 rounded transition">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="px-4 py-8 text-center text-gray-400">
                    No hay productos registrados.
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>


<div class="mt-6 flex justify-center">
    <?php echo e($productos->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\backend_560\560_ExamenParcial2\resources\views/productos/index.blade.php ENDPATH**/ ?>