<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductoRequest extends FormRequest
{
    // Autorizar la solicitud (true = permitir a todos)
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Obtener el ID del producto actual (para update ignorar su propio SKU)
        $productoId = $this->route('producto')?->id;

        return [
            'nombre'       => ['required', 'string', 'max:150'],
            'codigo'          => [
                                'required',
                                'string',
                                'max:50',
                                Rule::unique('productos', 'codigo')->ignore($productoId),
                              ],
            'precio'       => ['required', 'numeric', 'min:0'],
            'stock'        => ['required', 'integer', 'min:0'],
            'disponible'   => ['nullable', 'boolean'],
            'categoria_id' => ['required', 'exists:categorias,id'],
        ];
    }

    // Mensajes personalizados en español
    public function messages(): array
    {
        return [
            'nombre.required'       => 'El nombre del producto es obligatorio.',
            'nombre.max'            => 'El nombre no puede superar los 150 caracteres.',
            'codigo.required'          => 'El Codigo es obligatorio.',
            'codigo.unique'            => 'Este Codigo ya está registrado, ingrese uno diferente.',
            'codigo.max'               => 'El Codigo no puede superar los 50 caracteres.',
            'precio.required'       => 'El precio es obligatorio.',
            'precio.numeric'        => 'El precio debe ser un número válido.',
            'precio.min'            => 'El precio no puede ser negativo.',
            'stock.required'        => 'El stock es obligatorio.',
            'stock.integer'         => 'El stock debe ser un número entero.',
            'stock.min'             => 'El stock no puede ser negativo.',
            'categoria_id.required' => 'Debe seleccionar una categoría.',
            'categoria_id.exists'   => 'La categoría seleccionada no existe.',
        ];
    }

    // Nombres de atributos en español (para mensajes genéricos)
    public function attributes(): array
    {
        return [
            'nombre'       => 'nombre',
            'codigo'          => 'codigo',
            'precio'       => 'precio',
            'stock'        => 'stock',
            'disponible'   => 'disponible',
            'categoria_id' => 'categoría',
        ];
    }

    // Preprocesar datos antes de validar
    protected function prepareForValidation(): void
    {
        // Convertir checkbox disponible a booleano
        $this->merge([
            'disponible' => $this->has('disponible') ? true : false,
        ]);
    }
    
}
