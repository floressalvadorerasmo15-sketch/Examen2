<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Producto;
use App\Http\Requests\ProductoRequest;
use Illuminate\Http\Request;

class ProductoController extends Controller
{
    // 1. Listar todos los productos
    public function index()
    {
        $productos = Producto::with('categoria')
                        ->orderBy('id', 'desc')
                        ->paginate(10);

        return view('productos.index', compact('productos'));
    }

    // 2. Mostrar formulario de creación
    public function create()
    {
        $categorias = Categoria::where('activo', true)->orderBy('nombre')->get();

        return view('productos.create', compact('categorias'));
    }

    // 3. Guardar nuevo producto
    public function store(ProductoRequest $request)
    {
        Producto::create($request->validated());

        return redirect()->route('productos.index')
                         ->with('success', '✅ Producto creado correctamente.');
    }

    // 4. Ver detalle de un producto
    public function show(Producto $producto)
    {
        $producto->load('categoria');

        return view('productos.show', compact('producto'));
    }

    // 5. Mostrar formulario de edición
    public function edit(Producto $producto)
    {
        $categorias = Categoria::where('activo', true)->orderBy('nombre')->get();

        return view('productos.edit', compact('producto', 'categorias'));
    }

    // 6. Actualizar producto existente
    public function update(ProductoRequest $request, Producto $producto)
    {
        $producto->update($request->validated());

        return redirect()->route('productos.index')
                         ->with('success', '✅ Producto actualizado correctamente.');
    }

    // 7. Eliminar producto
    public function destroy(Producto $producto)
    {
        $producto->delete();

        return redirect()->route('productos.index')
                         ->with('success', '🗑️ Producto eliminado correctamente.');
    }
}
