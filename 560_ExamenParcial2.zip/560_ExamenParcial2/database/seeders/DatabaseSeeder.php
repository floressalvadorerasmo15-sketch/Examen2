<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Primero categorías, luego productos (orden importante)
        $this->call([
            CategoriaSeeder::class,
            ProductoSeeder::class,
        ]);
    }
}