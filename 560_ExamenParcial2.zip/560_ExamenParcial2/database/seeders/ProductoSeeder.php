<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Seeder;

class ProductoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // 1. Borramos el factory aleatorio y creamos una lista fija de productos reales en español
        $productos = [
            [
                'nombre' => 'Teclado Mecánico RGB',
                'codigo' => 'COD-3920-XN',
                'precio' => 350.00,
                'stock' => 25,
                'disponible' => true,
                'categoria_id' => 1 // Asegúrate de que este ID exista en tus categorías
            ],
            [
                'nombre' => 'Mouse Gamer Óptico',
                'codigo' => 'COD-6936-MA',
                'precio' => 180.50,
                'stock' => 119,
                'disponible' => true,
                'categoria_id' => 2
            ],
            [
                'nombre' => 'Monitor Gamer 24 Pulgadas',
                'codigo' => 'COD-5928-KD',
                'precio' => 1200.00,
                'stock' => 82,
                'disponible' => true,
                'categoria_id' => 1
            ],
            [
                'nombre' => 'Polera de Algodón Negra',
                'codigo' => 'COD-1296-ST',
                'precio' => 85.00,
                'stock' => 96,
                'disponible' => true,
                'categoria_id' => 4
            ],
            [
                'nombre' => 'Chaqueta Impermeable',
                'codigo' => 'COD-8178-OY',
                'precio' => 250.00,
                'stock' => 174,
                'disponible' => true,
                'categoria_id' => 3
            ],
            [
                'nombre' => 'Café Premium Destilado',
                'codigo' => 'COD-0875-XI',
                'precio' => 45.00,
                'stock' => 126,
                'disponible' => false, // Mostrará el estado "No disponible"
                'categoria_id' => 4
            ],
            [
                'nombre' => 'Juego de Ollas de Acero',
                'codigo' => 'COD-7211-HU',
                'precio' => 580.00,
                'stock' => 86,
                'disponible' => true,
                'categoria_id' => 4
            ],
            [
                'nombre' => 'Lámpara de Escritorio LED',
                'codigo' => 'COD-9674-FH',
                'precio' => 120.00,
                'stock' => 59,
                'disponible' => true,
                'categoria_id' => 4
            ]
        ];

        // 2. Registramos los productos uno por uno en la base de datos
        foreach ($productos as $producto) {
            Producto::create($producto);
        }
    }
}