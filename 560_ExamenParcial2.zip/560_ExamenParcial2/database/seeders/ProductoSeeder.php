<?php

namespace Database\Seeders;

use App\Models\Producto;
use Illuminate\Database\Seeder;

class ProductoSeeder extends Seeder
{
    public function run(): void
    {
        // Genera 20 productos usando la factory
        Producto::factory()->count(20)->create();
    }
}