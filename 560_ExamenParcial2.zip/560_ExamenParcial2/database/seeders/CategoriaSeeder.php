<?php

namespace Database\Seeders;

use App\Models\Categoria;
use Illuminate\Database\Seeder;

class CategoriaSeeder extends Seeder
{
    public function run(): void
    {
        // Categorías fijas y realistas
        $categorias = [
            ['nombre' => 'Electrónica',   'descripcion' => 'Dispositivos y gadgets electrónicos', 'activo' => true],
            ['nombre' => 'Ropa',          'descripcion' => 'Prendas de vestir para toda ocasión',  'activo' => true],
            ['nombre' => 'Alimentos',     'descripcion' => 'Productos alimenticios y bebidas',     'activo' => true],
            ['nombre' => 'Hogar',         'descripcion' => 'Artículos para el hogar',              'activo' => true],
            ['nombre' => 'Deportes',      'descripcion' => 'Equipos y ropa deportiva',             'activo' => true],
        ];

        foreach ($categorias as $categoria) {
            Categoria::create($categoria);
        }
    }
}