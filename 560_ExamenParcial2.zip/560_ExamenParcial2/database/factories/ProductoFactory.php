<?php

namespace Database\Factories;

use App\Models\Categoria;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductoFactory extends Factory
{
    public function definition(): array
    {
        return [
            'categoria_id' => Categoria::inRandomOrder()->first()->id,
            'nombre'       => fake()->words(3, true),
            'codigo'          => strtoupper(fake()->unique()->bothify('COD-####-??')),
            'precio'       => fake()->randomFloat(2, 5.00, 999.99),
            'stock'        => fake()->numberBetween(0, 200),
            'disponible'   => fake()->boolean(75), // 75% de probabilidad true
        ];
    }
}