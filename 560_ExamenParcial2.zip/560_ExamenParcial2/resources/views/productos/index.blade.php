@extends('layouts.app')

@section('title', 'Lista de Productos')

@section('content')

<div class="flex items-center justify-between mb-6">
    <h2 class="text-2xl font-bold text-gray-800">📦 Productos</h2>
    <a href="{{ route('productos.create') }}"
       class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded shadow transition">
        + Nuevo Producto
    </a>
</div>

<div class="bg-white rounded-xl shadow overflow-hidden">
    <table class="min-w-full text-sm text-left">
        <thead class="bg-gray-900 text-white">
            <tr>
                <th class="px-4 py-3">#</th>
                <th class="px-4 py-3">Nombre</th>
                <th class="px-4 py-3">Codigo</th>
                <th class="px-4 py-3">Categoría</th>
                <th class="px-4 py-3">Precio</th>
                <th class="px-4 py-3">Stock</th>
                <th class="px-4 py-3">Disponible</th>
                <th class="px-4 py-3 text-center">Acciones</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            @forelse($productos as $producto)
            <tr class="hover:bg-gray-50 transition">
                <td class="px-4 py-3 text-gray-500">{{ $producto->id }}</td>
                <td class="px-4 py-3 font-medium text-gray-800">{{ $producto->nombre }}</td>
                <td class="px-4 py-3">
                    <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded font-mono text-xs">
                        {{ $producto->codigo }}
                    </span>
                </td>
                <td class="px-4 py-3 text-gray-600">{{ $producto->categoria->nombre ?? '—' }}</td>
                <td class="px-4 py-3 text-gray-800 font-semibold">
                    Bs. {{ number_format($producto->precio, 2) }}
                </td>
                <td class="px-4 py-3 text-gray-700">{{ $producto->stock }}</td>
                <td class="px-4 py-3">
                    @if($producto->disponible)
                        <span class="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-full">Sí</span>
                    @else
                        <span class="bg-gray-200 text-gray-600 text-xs font-semibold px-2 py-1 rounded-full">No</span>
                    @endif
                </td>
                <td class="px-4 py-3 text-center space-x-1">
                    {{-- Ver --}}
                    <a href="{{ route('productos.show', $producto) }}"
                       class="inline-block bg-cyan-500 hover:bg-cyan-600 text-white text-xs font-semibold px-3 py-1 rounded transition">
                        Ver
                    </a>

                    {{-- Editar --}}
                    <a href="{{ route('productos.edit', $producto) }}"
                       class="inline-block bg-yellow-400 hover:bg-yellow-500 text-white text-xs font-semibold px-3 py-1 rounded transition">
                        Editar
                    </a>

                    {{-- Eliminar --}}
                    <form action="{{ route('productos.destroy', $producto) }}"
                          method="POST"
                          class="inline-block"
                          onsubmit="return confirm('¿Estás seguro de eliminar: {{ $producto->nombre }}?')">
                        @csrf
                        @method('DELETE')
                        <button type="submit"
                                class="bg-red-500 hover:bg-red-600 text-white text-xs font-semibold px-3 py-1 rounded transition">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="px-4 py-8 text-center text-gray-400">
                    No hay productos registrados.
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Paginación --}}
<div class="mt-6 flex justify-center">
    {{ $productos->links() }}
</div>

@endsection