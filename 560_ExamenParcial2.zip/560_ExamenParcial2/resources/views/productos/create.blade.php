@extends('layouts.app')

@section('title', 'Nuevo Producto')

@section('content')

<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-xl shadow overflow-hidden">

        <div class="bg-blue-600 px-6 py-4">
            <h2 class="text-white text-xl font-bold">➕ Nuevo Producto</h2>
        </div>

        <div class="p-6">

            {{-- Errores --}}
            @if($errors->any())
                <div class="mb-5 bg-red-50 border border-red-300 text-red-700 px-4 py-3 rounded">
                    <ul class="list-disc list-inside text-sm space-y-1">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('productos.store') }}" method="POST" class="space-y-5">
                @csrf

                {{-- Nombre --}}
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">
                        Nombre <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="nombre" value="{{ old('nombre') }}"
                           class="w-full border {{ $errors->has('nombre') ? 'border-red-400 bg-red-50' : 'border-gray-300' }} rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                    @error('nombre')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- SKU --}}
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">
                        SKU <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="codigo" value="{{ old('codigo') }}"
                           class="w-full border {{ $errors->has('codigo') ? 'border-red-400 bg-red-50' : 'border-gray-300' }} rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                    @error('codigo')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Precio y Stock --}}
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">
                            Precio (Bs.) <span class="text-red-500">*</span>
                        </label>
                        <input type="number" name="precio" value="{{ old('precio') }}"
                               step="0.01" min="0"
                               class="w-full border {{ $errors->has('precio') ? 'border-red-400 bg-red-50' : 'border-gray-300' }} rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                        @error('precio')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-1">
                            Stock <span class="text-red-500">*</span>
                        </label>
                        <input type="number" name="stock" value="{{ old('stock', 0) }}"
                               min="0"
                               class="w-full border {{ $errors->has('stock') ? 'border-red-400 bg-red-50' : 'border-gray-300' }} rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                        @error('stock')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                {{-- Categoría --}}
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-1">
                        Categoría <span class="text-red-500">*</span>
                    </label>
                    <select name="categoria_id"
                            class="w-full border {{ $errors->has('categoria_id') ? 'border-red-400 bg-red-50' : 'border-gray-300' }} rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400">
                        <option value="">-- Seleccione una categoría --</option>
                        @foreach($categorias as $categoria)
                            <option value="{{ $categoria->id }}"
                                {{ old('categoria_id') == $categoria->id ? 'selected' : '' }}>
                                {{ $categoria->nombre }}
                            </option>
                        @endforeach
                    </select>
                    @error('categoria_id')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                {{-- Disponible --}}
                <div class="flex items-center gap-2">
                    <input type="checkbox" name="disponible" id="disponible"
                           class="w-4 h-4 accent-blue-600"
                           {{ old('disponible', true) ? 'checked' : '' }}>
                    <label for="disponible" class="text-sm font-semibold text-gray-700">
                        Disponible
                    </label>
                </div>

                {{-- Botones --}}
                <div class="flex gap-3 pt-2">
                    <button type="submit"
                            class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2 rounded-lg transition">
                        💾 Guardar
                    </button>
                    <a href="{{ route('productos.index') }}"
                       class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold px-5 py-2 rounded-lg transition">
                        Cancelar
                    </a>
                </div>

            </form>
        </div>
    </div>
</div>

@endsection