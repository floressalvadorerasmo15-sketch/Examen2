@extends('layouts.app')

@section('title', 'Detalle del Producto')

@section('content')

<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-xl shadow overflow-hidden">

        <div class="bg-cyan-500 px-6 py-4">
            <h2 class="text-white text-xl font-bold">🔍 Detalle del Producto</h2>
        </div>

        <div class="p-6">
            <dl class="divide-y divide-gray-100 text-sm">

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">ID</dt>
                    <dd class="col-span-2 text-gray-800">{{ $producto->id }}</dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Nombre</dt>
                    <dd class="col-span-2 text-gray-800">{{ $producto->nombre }}</dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">codigo</dt>
                    <dd class="col-span-2">
                        <span class="bg-gray-100 text-gray-700 px-2 py-1 rounded font-mono text-xs">
                            {{ $producto->codigo }}
                        </span>
                    </dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Categoría</dt>
                    <dd class="col-span-2 text-gray-800">{{ $producto->categoria->nombre ?? '—' }}</dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Precio</dt>
                    <dd class="col-span-2 font-semibold text-gray-800">
                        Bs. {{ number_format($producto->precio, 2) }}
                    </dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Stock</dt>
                    <dd class="col-span-2 text-gray-800">{{ $producto->stock }}</dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Disponible</dt>
                    <dd class="col-span-2">
                        @if($producto->disponible)
                            <span class="bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-full">Sí</span>
                        @else
                            <span class="bg-gray-200 text-gray-600 text-xs font-semibold px-2 py-1 rounded-full">No</span>
                        @endif
                    </dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Creado</dt>
                    <dd class="col-span-2 text-gray-500">{{ $producto->created_at->format('d/m/Y H:i') }}</dd>
                </div>

                <div class="py-3 grid grid-cols-3 gap-4">
                    <dt class="font-semibold text-gray-600">Actualizado</dt>
                    <dd class="col-span-2 text-gray-500">{{ $producto->updated_at->format('d/m/Y H:i') }}</dd>
                </div>

            </dl>

            <div class="flex gap-3 mt-6">
                <a href="{{ route('productos.edit', $producto) }}"
                   class="bg-yellow-400 hover:bg-yellow-500 text-white font-semibold px-5 py-2 rounded-lg transition">
                    ✏️ Editar
                </a>
                <a href="{{ route('productos.index') }}"
                   class="bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold px-5 py-2 rounded-lg transition">
                    ← Volver
                </a>
            </div>
        </div>
    </div>
</div>

@endsection